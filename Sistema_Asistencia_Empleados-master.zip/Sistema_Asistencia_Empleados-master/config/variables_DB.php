<?php
define('DB_HOST', 'localhost');
define('DB_USUARIO', 'root');
define('DB_CONTRA', '');
define('DB_NOMBRE','asistencia_empleados');
define('DB_CHARSET', 'utf8');
?>